(() => {
  let range = null, owner = null, lastContact = 0, lastSeek = 0, seeking = false, ticking = false, error = '', episode = location.pathname;
  const video = () => [...document.querySelectorAll('video')].find(v => v.duration > 0 && v.getBoundingClientRect().width > 0);
  const reset = () => { range = null; owner = null; error = ''; };
  async function native(action, extra = {}) {
    const result = await chrome.runtime.sendMessage({ source: 'listening-coach-native', command: { action, watchId: episode.match(/^\/watch\/(\d+)/)?.[1], ...extra } });
    if (!result || result.failed) throw Error(result?.error || 'Netflix 플레이어에 연결하지 못했어요. 확장 프로그램과 두 탭을 새로고침해 주세요.');
    return result;
  }
  async function seek(time) {
    if (seeking) throw Error('이전 구간 이동을 기다려 주세요.');
    seeking = true;
    const path = episode;
    try {
      await native('seek', { time });
      // Wait for native buffering; never fall back to assigning video.currentTime.
      for (let attempt = 0; attempt < 10; attempt++) {
        await new Promise(resolve => setTimeout(resolve, 250));
        if (location.pathname !== path) throw Error('회차가 바뀌어 구간 이동을 중단했어요.');
        if (Math.abs((await native('status')).time - time) < 3) return;
      }
      throw Error('구간 이동을 확인하지 못해 반복을 껐어요. Netflix 탭에서 재생 상태를 확인해 주세요.');
    } finally { seeking = false; }
  }
  async function status(v) {
    const timing = v ? await native('status') : { time: 0, duration: 0 };
    // innerText preserves rendered <br> / block boundaries that textContent drops.
    const subtitle = (document.querySelector('.player-timedtext-text-container')?.innerText ?? '')
      .replace(/\u00a0/g, ' ').split(/\r?\n/).map(line => line.replace(/[\t ]+/g, ' ').trim()).filter(Boolean).join('\n').slice(0, 2000);
    return { watchId: location.pathname.match(/^\/watch\/(\d+)/)?.[1], ready: !!v,
      ...timing, paused: v?.paused ?? true, loop: !!range?.loop, start: range?.start, end: range?.end, error,
      subtitle };
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || message?.source !== 'listening-coach-controller') return false;
    async function act() {
      if (episode !== location.pathname) { reset(); episode = location.pathname; }
      const c = message.command, v = video();
      if (location.pathname !== '/watch/' + c.watchId && location.pathname !== '/watch/' + c.watchId + '/') throw Error('다음 회차로 이동했어요. 앱에서 다시 연결해 주세요.');
      if (owner !== null && owner !== message.owner && Date.now() - lastContact < 15000) throw Error('다른 학습 앱 탭에서 연결 중이에요. 먼저 연결을 해제해 주세요.');
      if (c.action === 'disconnect') { reset(); return { ready: false, loop: false }; }
      owner = message.owner; lastContact = Date.now();
      if (c.action === 'status') return status(v);
      if (!v) throw Error('Netflix에서 본편을 먼저 재생해 주세요.');
      error = '';
      if (c.action === 'play' || c.action === 'pause') await native(c.action);
      else if (c.action === 'seek') { if (range && (c.time < range.start || c.time >= range.end)) range.loop = false; await seek(c.time); }
      else if (c.action === 'range') {
        const timing = await native('status');
        if (!(Number.isFinite(c.start) && Number.isFinite(c.end) && c.start >= 0 && c.end > c.start && c.end <= timing.duration)) throw Error('끝 시각을 시작 이후, 영상 길이 안으로 설정해 주세요.');
        const next = { start: c.start, end: c.end, loop: false }; range = next;
        if (c.loop) { await seek(c.start); if (range === next && episode === location.pathname) next.loop = true; }
      } else throw Error('지원하지 않는 명령이에요.');
      return status(v);
    }
    act().then(respond, e => { if (owner === message.owner) { error = e.message; if (range) range.loop = false; } respond({ error: e.message, failed: true }); });
    return true;
  });
  setInterval(async () => {
    if (episode !== location.pathname || Date.now() - lastContact > 15000) { reset(); episode = location.pathname; return; }
    const v = video();
    if (!v || !range?.loop || seeking || ticking || (v.paused && !v.ended) || v.seeking || v.readyState < 2 || Date.now() - lastSeek < 1200) return;
    ticking = true;
    const activeRange = range;
    try {
      const timing = await native('status');
      if (range !== activeRange || !range.loop || episode !== location.pathname || Date.now() - lastContact > 15000 || timing.time < range.end - .1) return;
      lastSeek = Date.now();
      const ended = v.ended;
      await seek(range.start);
      if (ended && range === activeRange && range.loop) await native('play');
    } catch (e) { error = e.message; if (range) range.loop = false; }
    finally { ticking = false; }
  }, 250);
})();
