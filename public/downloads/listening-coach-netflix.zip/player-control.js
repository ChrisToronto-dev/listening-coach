// Chrome serializes this function into Netflix's MAIN world. Never write to
// HTMLMediaElement.currentTime: Netflix must manage its own media pipeline.
export async function netflixControl(command) {
  try {
    if (location.origin !== 'https://www.netflix.com' || location.pathname.match(/^\/watch\/(\d+)\/?$/)?.[1] !== command.watchId) throw Error('영상이 바뀌었어요. 앱에서 다시 연결해 주세요.');
    if (!['status', 'seek', 'play', 'pause'].includes(command.action)) throw Error('지원하지 않는 재생 명령이에요.');
    const api = window.netflix?.appContext?.state?.playerApp?.getAPI?.()?.videoPlayer;
    const ids = api?.getAllPlayerSessionIds?.()?.filter(id => typeof id === 'string' && id.startsWith('watch-')) ?? [];
    if (ids.length !== 1) throw Error('Netflix 본편 플레이어를 찾지 못했어요. 본편을 재생한 뒤 다시 연결해 주세요.');
    const p = api.getVideoPlayerBySessionId(ids[0]);
    if (!p || !['getCurrentTime', 'getDuration', 'seek', 'play', 'pause'].every(key => typeof p[key] === 'function')) throw Error('현재 Netflix 플레이어에서는 재생 제어를 사용할 수 없어요.');
    const duration = p.getDuration() / 1000;
    if (!Number.isFinite(duration) || duration <= 0) throw Error('Netflix 본편이 준비될 때까지 기다려 주세요.');
    if (command.action === 'seek') {
      if (!Number.isFinite(command.time) || command.time < 0 || command.time > duration) throw Error('영상 길이 안에서 시각을 선택해 주세요.');
      await p.seek(Math.round(command.time * 1000));
    } else if (command.action === 'play') await p.play();
    else if (command.action === 'pause') await p.pause();
    const time = p.getCurrentTime() / 1000;
    if (!Number.isFinite(time)) throw Error('Netflix 재생 시각을 읽지 못했어요.');
    return { time, duration };
  } catch (e) { return { failed: true, error: e.message || 'Netflix 플레이어 명령을 실행하지 못했어요.' }; }
}
